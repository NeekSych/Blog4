import PostForm from './PostForm';

export default PostForm;
